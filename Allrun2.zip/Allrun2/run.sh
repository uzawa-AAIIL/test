#!/bin/bash

./clean.sh

blockMesh | tee log.blockMesh
icoReactingMultiphaseInterFoam | tee log.icoReactingMultiphaseInterFoam

